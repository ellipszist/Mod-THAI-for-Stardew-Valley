function entry(location,tile,layer)
	TMX.SetSpouseRoom(location);
end